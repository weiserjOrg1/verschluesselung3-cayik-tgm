package cayik.cipher;
/*
 * This test class executes the whole thing.
 * 
 * @autor cayik
 * @verison 2018-10-20
 */

public class Test {
	public static void main(String[] args) {
		Controll c1=new Controll();
		
	}
}
